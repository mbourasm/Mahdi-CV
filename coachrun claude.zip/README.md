# CoachRun — application iOS + watchOS

Reprise complète du prototype décrit dans `COACHRUN_CONTEXT.md`.
Swift 5.9 / SwiftUI / HealthKit / WatchConnectivity.

Cibles : **iOS 17+** et **watchOS 10+**.

---

## 1. Audit du prototype fourni

Ce qui a été trouvé dans `CoachRun_Final_Source.zip`, et ce qui a été fait.

| Problème du prototype | Correction apportée |
|---|---|
| `CoachEngine.tick` comparait `highSeconds == toleranceSeconds` : si un tick était manqué, l'alerte n'était **jamais** déclenchée. Aucune répétition, aucun anti-bavardage. | Moteur réécrit en temps réel (`dt`), déclenchement au franchissement du seuil, répétition espacée tant que la FC reste hors plage, silence minimal entre deux prises de parole. |
| `WorkoutManager` n'appelait jamais `endCollection` ni `finishWorkout` : **la séance n'était pas enregistrée dans Apple Santé**. | Cycle de vie complet `HKWorkoutSession` + `HKLiveWorkoutBuilder`, avec API à complétion encapsulées dans des continuations (pas de dépendance à une variante async incertaine). |
| Aucune pause/reprise. | `pause()` / `resume()` / `end(completed:)`, avec chronomètre de temps actif (les pauses ne comptent pas). |
| `blockElapsed` incrémenté de 1 par tick : dérive garantie sur 50 minutes. | Temps basé sur `Date`, avec recalage sur l'offset théorique du bloc à chaque changement. |
| `speedKmh` lu via `HKQuantityTypeIdentifier.runningSpeed` : indisponible/instable sur tapis. | Vitesse calculée sur une fenêtre glissante de 20 s à partir de la distance, lissée. Fonctionne en extérieur **et** sur tapis. |
| `distanceWalkingRunning` lu via `mostRecentQuantity()` (valeur d'un échantillon, pas le cumul). | Lecture via `sumQuantity()` pour la distance et l'énergie, `mostRecentQuantity()` pour la FC uniquement. |
| `WorkoutResult`, splits, série FC : structures déclarées mais **jamais remplies**. | Échantillonnage 1 Hz pendant la séance + module `RunAnalytics` qui construit série FC, splits kilométriques et statistiques par bloc. |
| Aucune persistance : tout disparaissait à la fermeture. | `FileStore` JSON atomique : séances, historique, zones FC côté iPhone ; séance reçue, file d'attente des résultats et 10 derniers résultats côté Watch. |
| Aucune remontée Watch → iPhone. | `transferFile` avec file d'attente persistante et accusé de réception : un résultat n'est supprimé de la Watch qu'une fois livré. |
| Correction de distance tapis affichée mais jamais sauvegardée. | Correction persistée, distance brute conservée, splits et distances par bloc recalculés proportionnellement. |
| Zones FC absentes. | Zones entièrement configurables (% FC max, réserve de FC / Karvonen, ou bpm bruts) + durée et pourcentage par zone. |
| Deux `WCSessionDelegate` distincts côté Watch (un seul est autorisé par process). | Un `WatchSessionManager` unique gère réception des séances et envoi des résultats. |
| Audio : aucune `AVAudioSession` configurée, la première phrase pouvait être perdue et la musique n'était pas atténuée. | Catégorie `.playback` / `.spokenAudio` avec `duckOthers`, activation/désactivation gérées autour de chaque annonce. |
| Un seul motif haptique pour tout. | Motifs distincts : FC haute, FC basse, retour en zone, changement de bloc, fin de séance. |
| Éditeur limité, pas de suppression ni réordonnancement des blocs. | Blocs illimités, réordonnables, supprimables ; conversion allure ⟷ vitesse maintenue en permanence. |
| Un kilomètre était implicitement attribué à un seul bloc. | Chaque split stocke la répartition réelle du temps entre les blocs et signale les kilomètres à cheval. |

---

## 2. Arborescence

```
CoachRun/
├── project.yml                 # génération du projet Xcode (XcodeGen)
├── Resources/                  # Info.plist et entitlements des deux targets
├── Shared/                     # à ajouter aux DEUX targets
│   ├── Models.swift            # RunType, WorkoutBlock, WorkoutPlan, WorkoutResult, PaceMath
│   ├── CoachEngine.swift       # logique de tolérance FC + phrases françaises
│   ├── HRZones.swift           # zones configurables + répartition du temps
│   ├── RunAnalytics.swift      # splits, stats par bloc, série FC
│   └── Persistence.swift       # stockage JSON + clés WatchConnectivity
├── iOS/                        # target iPhone uniquement
│   ├── CoachRunApp.swift, AppStore.swift, WatchSyncManager.swift
│   ├── HealthProfileStore.swift
│   ├── PlansView.swift, WorkoutEditorView.swift
│   ├── HistoryView.swift, ResultDetailView.swift
│   └── ProgressionView.swift, ProfileView.swift
└── Watch/                      # target watchOS uniquement
    ├── CoachRunWatchApp.swift, WatchViews.swift
    ├── WorkoutManager.swift    # HealthKit, coach, blocs, pause/fin
    ├── CoachSpeaker.swift      # voix fr-FR + haptique
    └── WatchSessionManager.swift
```

---

## 3. Installation

### Option A — XcodeGen (recommandée, 2 minutes)

```bash
brew install xcodegen
cd CoachRun
xcodegen generate
open CoachRun.xcodeproj
```

Puis dans Xcode : sélectionne ton compte Apple dans *Signing & Capabilities* pour
les **deux** targets. Les capacités HealthKit et les Info.plist sont déjà en place.

### Option B — projet Xcode créé à la main

1. Xcode → File → New → Project → **watchOS → App**, option
   *Watch App with New Companion iOS App*, nom `CoachRun`.
2. Supprime les fichiers Swift générés par défaut.
3. Glisse `Shared/` dans le projet et coche **les deux targets**.
4. Glisse `iOS/` — target iOS uniquement.
5. Glisse `Watch/` — target watchOS uniquement.
6. Ajoute la capacité **HealthKit** aux deux targets.
7. Sur la target Watch, ajoute le mode d'arrière-plan **Workout processing**.
8. Recopie les clés `NSHealthShareUsageDescription` et
   `NSHealthUpdateUsageDescription` depuis `Resources/` dans les deux Info.plist.
9. Même équipe de signature pour les deux targets.

### Premier lancement

1. Lance la target iOS sur l'iPhone, accepte les autorisations Santé.
2. Lance la target Watch sur la Watch, accepte les autorisations Santé.
3. Sur l'iPhone : ouvre une séance → **Envoyer sur l'Apple Watch**.
4. Sur la Watch : la séance apparaît sur l'écran d'accueil → **Démarrer**.

---

## 4. Fonctionnement

**iPhone** : création des séances (blocs illimités : nom, durée, cible, plage FC,
tolérance), envoi vers la Watch, historique persistant, courbe FC colorée par bloc,
zones FC, tableau kilomètre par kilomètre, statistiques par bloc, correction de la
distance tapis, progression entre séances, profil Apple Santé.

**Watch** : exécution autonome. Trois pages verticales — métriques (bloc, temps,
FC, **allure min/km et vitesse km/h affichées simultanément**, distance, kcal),
détail du bloc, contrôles (pause/reprise/terminer, voix). Coach vocal français,
vibrations distinctes, annonce de chaque changement de bloc avec durée et cibles.

**Coach** : le compteur de dépassement s'accumule seulement tant que la FC est
hors plage et repart à zéro dès le retour dans la plage. Exemple conforme au
cahier des charges : cible 135–145, tolérance 120 s → 147 bpm pendant 30 s puis
retour à 142 ⇒ aucune alerte ; 120 s consécutives au-dessus ⇒ alerte ; retour
dans la zone ⇒ confirmation.

**Correction tapis** : la valeur brute de la Watch est conservée, la distance
saisie devient la référence, splits et distances par bloc sont mis à l'échelle.

---

## 5. Test recommandé avant une vraie séance

Crée une séance de 3 blocs d'1 minute, plage FC volontairement proche de ta FC
actuelle, tolérance 15 s, puis vérifie :

- [ ] voix française audible (avec et sans AirPods) ;
- [ ] vibration différente selon FC haute / FC basse / retour en zone / bloc suivant ;
- [ ] annonce du bloc avec durée et cible ;
- [ ] allure **et** vitesse affichées simultanément ;
- [ ] pause puis reprise : le chrono ne compte pas la pause ;
- [ ] fin de séance : résumé sur la Watch, séance visible dans Apple Santé ;
- [ ] séance apparue dans l'historique iPhone (mets l'iPhone en avion pendant
      la course pour vérifier la file d'attente et la livraison différée) ;
- [ ] test tapis : correction de distance puis réouverture de l'app pour vérifier
      qu'elle est bien persistée.

---

## 6. Ce qui reste à valider sur un vrai Mac et de vrais appareils

Je n'ai pas pu compiler ce code : cela nécessite Xcode sur macOS. À faire au
premier build, avant de perdre l'accès au Mac :

1. Compiler les deux targets et corriger les éventuels écarts d'API liés à ta
   version exacte de Xcode/iOS/watchOS.
2. Vérifier le comportement audio réel avec AirPods pendant un effort.
3. Vérifier la consommation batterie sur une séance longue.
4. Tester en extérieur (GPS) et sur tapis (distance au poignet).
5. Vérifier l'enregistrement dans Apple Santé et la cohérence des kcal.

---

## 7. Signature, SideStore : point à ne pas prendre à la légère

Avec un compte Apple Developer gratuit, une build de développement est signée
pour une durée limitée et doit être réinstallée/renouvelée.

**Je ne peux pas te garantir que SideStore renouvelle une app watchOS companion.**
Ce point n'a pas été établi de façon fiable et c'est le principal risque du projet :
il est possible que le renouvellement fonctionne pour l'app iPhone sans que
l'app Watch reste utilisable.

À faire **pendant que tu as encore accès au Mac** :

1. Installe l'app par Xcode sur iPhone + Watch, et note la date d'expiration.
2. Installe et configure SideStore immédiatement, sans attendre.
3. Fais un renouvellement de test via SideStore, puis vérifie explicitement que
   l'app **Watch** se lance encore et démarre bien une séance.
4. Si le renouvellement ne couvre pas la Watch, il faudra arbitrer entre :
   l'Apple Developer Program payant (renouvellement d'un an, signature à distance),
   ou un accès ponctuel régulier à un Mac.

Vérifie la documentation SideStore à jour au moment de l'installation : ce
comportement peut avoir changé.
